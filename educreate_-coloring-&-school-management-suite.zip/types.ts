
export enum AppView {
  DASHBOARD = 'DASHBOARD',
  COLORING_BOOK = 'COLORING_BOOK',
  SCHOOL_MANAGEMENT = 'SCHOOL_MANAGEMENT',
  EXAM_CENTER = 'EXAM_CENTER'
}

export interface Student {
  id: string;
  name: string;
  className: number;
  teacher?: string;
}

export interface Question {
  id: string;
  text: string;
  className: number;
}

export interface ColoringPage {
  imageUrl: string;
  theme: string;
}

export enum ImageSize {
  K1 = '1K',
  K2 = '2K',
  K4 = '4K'
}
