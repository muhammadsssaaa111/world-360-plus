
import React, { useState } from 'react';
import { AppView } from './types';
import ColoringBook from './components/ColoringBook';
import SchoolManagement from './components/SchoolManagement';
import ExamCenter from './components/ExamCenter';
import Chatbot from './components/Chatbot';
import ApiKeyGate from './components/ApiKeyGate';

const App: React.FC = () => {
  const [view, setView] = useState<AppView>(AppView.DASHBOARD);

  const NavItem: React.FC<{ target: AppView; label: string; icon: string }> = ({ target, label, icon }) => (
    <button
      onClick={() => setView(target)}
      className={`flex items-center gap-3 px-6 py-3 rounded-2xl font-black transition-all ${
        view === target 
          ? 'bg-white text-indigo-600 shadow-lg shadow-indigo-100' 
          : 'text-slate-500 hover:bg-slate-100'
      }`}
    >
      <i className={`fa-solid ${icon}`}></i>
      <span className="hidden md:inline">{label}</span>
    </button>
  );

  return (
    <ApiKeyGate>
      <div className="min-h-screen bg-slate-50 font-sans pb-24">
        {/* Navigation */}
        <nav className="sticky top-0 z-40 bg-white/80 backdrop-blur-md border-b border-slate-100 px-6 py-4 mb-8">
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-3 cursor-pointer" onClick={() => setView(AppView.DASHBOARD)}>
              <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white text-xl">
                <i className="fa-solid fa-graduation-cap"></i>
              </div>
              <h1 className="text-2xl font-black text-slate-800 tracking-tight">EduCreate</h1>
            </div>
            
            <div className="flex gap-2">
              <NavItem target={AppView.DASHBOARD} label="Home" icon="fa-house" />
              <NavItem target={AppView.SCHOOL_MANAGEMENT} label="School" icon="fa-school" />
              <NavItem target={AppView.EXAM_CENTER} label="Exams" icon="fa-file-invoice" />
              <NavItem target={AppView.COLORING_BOOK} label="Magic Art" icon="fa-palette" />
            </div>
          </div>
        </nav>

        {/* Main Content */}
        <main className="max-w-7xl mx-auto px-6">
          {view === AppView.DASHBOARD && (
            <div className="space-y-12 animate-fade-in">
              <div className="text-center py-12">
                <h2 className="text-5xl font-black text-slate-800 mb-4">Educational Tools Evolved.</h2>
                <p className="text-slate-500 text-xl max-w-2xl mx-auto">Manage your classroom, generate academic papers, and create personalized creative adventures for your students with the power of Gemini 3 AI.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div 
                  onClick={() => setView(AppView.SCHOOL_MANAGEMENT)}
                  className="bg-white p-8 rounded-[2rem] shadow-xl hover:shadow-2xl transition-all cursor-pointer group border border-slate-50"
                >
                  <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center text-3xl mb-6 group-hover:scale-110 transition-transform">
                    <i className="fa-solid fa-users-viewfinder"></i>
                  </div>
                  <h3 className="text-2xl font-black text-slate-800 mb-2">Student Records</h3>
                  <p className="text-slate-500 mb-6">Manage student rolls, track promotions, and organize class hierarchies with ease.</p>
                  <span className="text-blue-600 font-bold flex items-center gap-2">
                    Open Management <i className="fa-solid fa-arrow-right"></i>
                  </span>
                </div>

                <div 
                  onClick={() => setView(AppView.EXAM_CENTER)}
                  className="bg-white p-8 rounded-[2rem] shadow-xl hover:shadow-2xl transition-all cursor-pointer group border border-slate-50"
                >
                  <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center text-3xl mb-6 group-hover:scale-110 transition-transform">
                    <i className="fa-solid fa-clipboard-question"></i>
                  </div>
                  <h3 className="text-2xl font-black text-slate-800 mb-2">Exam Center</h3>
                  <p className="text-slate-500 mb-6">Build a robust question bank for every grade and generate PDF exam papers instantly.</p>
                  <span className="text-emerald-600 font-bold flex items-center gap-2">
                    Go to Exams <i className="fa-solid fa-arrow-right"></i>
                  </span>
                </div>

                <div 
                  onClick={() => setView(AppView.COLORING_BOOK)}
                  className="bg-white p-8 rounded-[2rem] shadow-xl hover:shadow-2xl transition-all cursor-pointer group border border-slate-50"
                >
                  <div className="w-16 h-16 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center text-3xl mb-6 group-hover:scale-110 transition-transform">
                    <i className="fa-solid fa-wand-magic-sparkles"></i>
                  </div>
                  <h3 className="text-2xl font-black text-slate-800 mb-2">Coloring Magic</h3>
                  <p className="text-slate-500 mb-6">Create AI-generated coloring books based on student names and custom themes.</p>
                  <span className="text-indigo-600 font-bold flex items-center gap-2">
                    Start Creating <i className="fa-solid fa-arrow-right"></i>
                  </span>
                </div>
              </div>
            </div>
          )}

          {view === AppView.SCHOOL_MANAGEMENT && <SchoolManagement />}
          {view === AppView.EXAM_CENTER && <ExamCenter />}
          {view === AppView.COLORING_BOOK && <ColoringBook />}
        </main>

        <Chatbot />
      </div>
    </ApiKeyGate>
  );
};

export default App;
