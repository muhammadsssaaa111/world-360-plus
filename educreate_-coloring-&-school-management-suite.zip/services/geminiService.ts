
import { GoogleGenAI } from "@google/genai";
import { ImageSize } from "../types";

export class GeminiService {
  private static getClient() {
    return new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  static async generateColoringPage(theme: string, size: ImageSize): Promise<string> {
    const ai = this.getClient();
    const prompt = `Thick black line art, black and white coloring book page for children, minimal detail, high contrast, white background, no grayscale, no shading, subject: ${theme}`;
    
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-image-preview',
      contents: {
        parts: [{ text: prompt }]
      },
      config: {
        imageConfig: {
          aspectRatio: "1:1",
          imageSize: size
        }
      }
    });

    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    throw new Error("No image data received from Gemini");
  }

  static async chatWithGemini(message: string, systemInstruction?: string) {
    const ai = this.getClient();
    const chat = ai.chats.create({
      model: 'gemini-3-pro-preview',
      config: {
        systemInstruction: systemInstruction || "You are a helpful educational assistant for a school management platform."
      }
    });

    const response = await chat.sendMessage({ message });
    return response.text;
  }

  static async generateQuestions(className: number, subject: string, count: number): Promise<string[]> {
    const ai = this.getClient();
    const prompt = `Generate ${count} simple school exam questions for Class ${className} students on the subject of ${subject}. Return the questions as a simple list.`;
    
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt
    });

    return response.text?.split('\n').filter(line => line.trim().length > 0) || [];
  }
}
