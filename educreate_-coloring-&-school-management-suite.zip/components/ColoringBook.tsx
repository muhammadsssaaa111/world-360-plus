
import React, { useState } from 'react';
import { GeminiService } from '../services/geminiService';
import { ImageSize } from '../types';
// @ts-ignore
const { jsPDF } = window.jspdf;

const ColoringBook: React.FC = () => {
  const [theme, setTheme] = useState('');
  const [childName, setChildName] = useState('');
  const [imageSize, setImageSize] = useState<ImageSize>(ImageSize.K1);
  const [pages, setPages] = useState<string[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [progress, setProgress] = useState(0);

  const generateBook = async () => {
    if (!theme || !childName) return;
    setIsGenerating(true);
    setPages([]);
    setProgress(0);

    const newPages: string[] = [];
    const themes = [
      `${theme} main character`,
      `${theme} in an action scene`,
      `${theme} landscape background`,
      `${theme} close-up portrait`,
      `${theme} group of items`
    ];

    try {
      for (let i = 0; i < 5; i++) {
        const imageUrl = await GeminiService.generateColoringPage(themes[i], imageSize);
        newPages.push(imageUrl);
        setProgress((i + 1) * 20);
      }
      setPages(newPages);
    } catch (err) {
      console.error(err);
      alert("Error generating coloring pages. Please try again.");
    } finally {
      setIsGenerating(false);
    }
  };

  const downloadPdf = () => {
    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();

    // Cover Page
    doc.setFillColor(79, 70, 229); // Indigo 600
    doc.rect(0, 0, pageWidth, pageHeight, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(40);
    doc.text("COLORING BOOK", pageWidth / 2, pageHeight / 3, { align: 'center' });
    doc.setFontSize(24);
    doc.text(`Created for ${childName}`, pageWidth / 2, pageHeight / 2, { align: 'center' });
    doc.setFontSize(18);
    doc.text(`Theme: ${theme}`, pageWidth / 2, pageHeight / 1.5, { align: 'center' });

    // Coloring Pages
    pages.forEach((imgData) => {
      doc.addPage();
      doc.addImage(imgData, 'PNG', 10, 10, pageWidth - 20, pageWidth - 20);
    });

    doc.save(`${childName}_Coloring_Book.pdf`);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fade-in">
      <div className="bg-white rounded-3xl shadow-xl overflow-hidden border border-slate-100">
        <div className="bg-indigo-600 px-8 py-10 text-white">
          <h2 className="text-3xl font-black mb-2 flex items-center gap-3">
            <i className="fa-solid fa-palette"></i>
            Magic Coloring Book Generator
          </h2>
          <p className="text-indigo-100 opacity-90">Create a personalized 5-page coloring adventure for your student.</p>
        </div>

        <div className="p-8 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-2">Child's Name</label>
              <input
                type="text"
                value={childName}
                onChange={(e) => setChildName(e.target.value)}
                placeholder="e.g. Leo"
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all"
              />
            </div>
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-2">Theme</label>
              <input
                type="text"
                value={theme}
                onChange={(e) => setTheme(e.target.value)}
                placeholder="e.g. Astronaut Dinosaurs"
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-bold text-slate-700 mb-4 text-center">Output Quality</label>
            <div className="flex justify-center gap-4">
              {[ImageSize.K1, ImageSize.K2, ImageSize.K4].map((size) => (
                <button
                  key={size}
                  onClick={() => setImageSize(size)}
                  className={`px-6 py-2 rounded-full font-bold transition-all ${
                    imageSize === size 
                      ? 'bg-indigo-600 text-white shadow-lg scale-105' 
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {size}
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={generateBook}
            disabled={isGenerating || !theme || !childName}
            className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 text-white font-black py-4 px-6 rounded-2xl shadow-xl transition-all flex items-center justify-center gap-3 active:scale-95"
          >
            {isGenerating ? (
              <>
                <i className="fa-solid fa-spinner fa-spin"></i>
                Generating Page {Math.floor(progress / 20) + 1}/5...
              </>
            ) : (
              <>
                <i className="fa-solid fa-wand-magic-sparkles"></i>
                Generate Coloring Book
              </>
            )}
          </button>
        </div>
      </div>

      {isGenerating && (
        <div className="bg-white p-6 rounded-2xl shadow-lg border border-indigo-100">
          <div className="flex justify-between text-sm font-bold text-indigo-600 mb-2">
            <span>Progress</span>
            <span>{progress}%</span>
          </div>
          <div className="w-full bg-slate-100 rounded-full h-3 overflow-hidden">
            <div 
              className="bg-indigo-600 h-full transition-all duration-500" 
              style={{ width: `${progress}%` }}
            ></div>
          </div>
        </div>
      )}

      {pages.length > 0 && !isGenerating && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-bold text-slate-800">Preview</h3>
            <button
              onClick={downloadPdf}
              className="bg-emerald-500 hover:bg-emerald-600 text-white font-bold py-2 px-6 rounded-xl shadow-lg flex items-center gap-2 transition-all active:scale-95"
            >
              <i className="fa-solid fa-file-pdf"></i>
              Download PDF
            </button>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {pages.map((page, idx) => (
              <div key={idx} className="bg-white p-2 rounded-xl shadow-md border border-slate-100 aspect-square overflow-hidden group">
                <img 
                  src={page} 
                  alt={`Page ${idx + 1}`} 
                  className="w-full h-full object-contain group-hover:scale-110 transition-transform cursor-pointer"
                  onClick={() => window.open(page)}
                />
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default ColoringBook;
