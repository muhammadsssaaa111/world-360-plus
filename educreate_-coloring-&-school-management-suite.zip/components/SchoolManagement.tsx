
import React, { useState } from 'react';
import { Student } from '../types';

interface SchoolData {
  name: string;
  teachers: Record<number, string>;
  students: Student[];
}

const SchoolManagement: React.FC = () => {
  const [schoolData, setSchoolData] = useState<SchoolData>({
    name: 'Excellence Primary School',
    teachers: {
      1: 'Mrs. Johnson',
      2: 'Mr. Smith',
      3: 'Ms. Davis',
      4: 'Mr. Wilson',
      5: 'Mrs. Taylor'
    },
    students: [
      { id: '1', name: 'Alice Smith', className: 1 },
      { id: '2', name: 'Bob Jones', className: 1 },
      { id: '3', name: 'Charlie Brown', className: 2 },
      { id: '4', name: 'Diana Prince', className: 3 },
      { id: '5', name: 'Ethan Hunt', className: 5 }
    ]
  });

  const [newStudentName, setNewStudentName] = useState('');
  const [selectedClass, setSelectedClass] = useState(1);

  const addStudent = () => {
    if (!newStudentName.trim()) return;
    const newStudent: Student = {
      id: Date.now().toString(),
      name: newStudentName,
      className: selectedClass
    };
    setSchoolData(prev => ({
      ...prev,
      students: [...prev.students, newStudent]
    }));
    setNewStudentName('');
  };

  const promoteStudent = (id: string) => {
    setSchoolData(prev => ({
      ...prev,
      students: prev.students.map(s => {
        if (s.id === id && s.className < 5) {
          return { ...s, className: s.className + 1 };
        }
        return s;
      })
    }));
  };

  const updateSchoolName = (name: string) => {
    setSchoolData(prev => ({ ...prev, name }));
  };

  const updateTeacher = (className: number, teacher: string) => {
    setSchoolData(prev => ({
      ...prev,
      teachers: { ...prev.teachers, [className]: teacher }
    }));
  };

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Header */}
      <div className="bg-white p-8 rounded-3xl shadow-xl border border-slate-100 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex-1">
          <label className="text-xs font-black text-indigo-500 uppercase tracking-widest mb-1 block">School Name</label>
          <input
            type="text"
            value={schoolData.name}
            onChange={(e) => updateSchoolName(e.target.value)}
            className="text-4xl font-black text-slate-800 bg-transparent border-none focus:ring-0 w-full outline-none"
          />
        </div>
        <div className="flex items-center gap-3 text-slate-400">
          <div className="text-right hidden md:block">
            <p className="text-sm font-bold text-slate-600">Total Students</p>
            <p className="text-2xl font-black text-indigo-600">{schoolData.students.length}</p>
          </div>
          <div className="w-12 h-12 bg-indigo-50 rounded-2xl flex items-center justify-center text-indigo-600 text-2xl">
            <i className="fa-solid fa-school"></i>
          </div>
        </div>
      </div>

      {/* Classes Overview */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        {[1, 2, 3, 4, 5].map(cls => (
          <div 
            key={cls}
            className={`p-6 rounded-2xl shadow-sm border-2 transition-all cursor-pointer ${
              selectedClass === cls ? 'bg-indigo-600 border-indigo-600 text-white scale-105 shadow-xl' : 'bg-white border-slate-100 text-slate-800 hover:border-indigo-200'
            }`}
            onClick={() => setSelectedClass(cls)}
          >
            <p className="text-xs font-black uppercase tracking-widest opacity-70">Class</p>
            <p className="text-3xl font-black">{cls}</p>
            <div className="mt-4 border-t border-white/20 pt-4">
              <input
                type="text"
                value={schoolData.teachers[cls]}
                onChange={(e) => updateTeacher(cls, e.target.value)}
                className="w-full bg-transparent text-xs font-bold border-none focus:ring-0 p-0"
              />
            </div>
          </div>
        ))}
      </div>

      {/* Content Area */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Student List */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-2xl font-black text-slate-800">Class {selectedClass} Students</h3>
            <span className="bg-slate-100 text-slate-600 px-3 py-1 rounded-full text-sm font-bold">
              {schoolData.students.filter(s => s.className === selectedClass).length} Students
            </span>
          </div>

          <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-100">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-100">
                  <th className="px-6 py-4 text-xs font-black text-slate-400 uppercase tracking-widest">Name</th>
                  <th className="px-6 py-4 text-xs font-black text-slate-400 uppercase tracking-widest text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {schoolData.students.filter(s => s.className === selectedClass).map(student => (
                  <tr key={student.id} className="hover:bg-slate-50 transition-colors group">
                    <td className="px-6 py-4">
                      <p className="font-bold text-slate-700">{student.name}</p>
                    </td>
                    <td className="px-6 py-4 text-right">
                      {student.className < 5 ? (
                        <button
                          onClick={() => promoteStudent(student.id)}
                          className="bg-emerald-50 text-emerald-600 hover:bg-emerald-100 px-4 py-2 rounded-xl text-sm font-bold transition-all flex items-center gap-2 ml-auto"
                        >
                          <i className="fa-solid fa-arrow-up"></i>
                          Promote
                        </button>
                      ) : (
                        <span className="text-slate-300 text-sm italic">Top Class</span>
                      )}
                    </td>
                  </tr>
                ))}
                {schoolData.students.filter(s => s.className === selectedClass).length === 0 && (
                  <tr>
                    <td colSpan={2} className="px-6 py-12 text-center text-slate-400 italic">
                      No students found in this class.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Add Student Form */}
        <div className="space-y-4">
          <h3 className="text-2xl font-black text-slate-800">Add New Student</h3>
          <div className="bg-white p-6 rounded-2xl shadow-xl border border-slate-100 space-y-4">
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-2">Student Name</label>
              <input
                type="text"
                value={newStudentName}
                onChange={(e) => setNewStudentName(e.target.value)}
                placeholder="Enter full name"
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none"
              />
            </div>
            <button
              onClick={addStudent}
              disabled={!newStudentName.trim()}
              className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-200 text-white font-black py-4 rounded-xl shadow-lg transition-all active:scale-95"
            >
              Enroll Student
            </button>
          </div>

          <div className="bg-indigo-50 p-6 rounded-2xl border border-indigo-100">
            <h4 className="font-black text-indigo-700 flex items-center gap-2 mb-2">
              <i className="fa-solid fa-lightbulb"></i>
              Quick Tip
            </h4>
            <p className="text-sm text-indigo-600 leading-relaxed">
              Promoting a student moves them to the next consecutive class level (e.g., Class 1 to Class 2).
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SchoolManagement;
