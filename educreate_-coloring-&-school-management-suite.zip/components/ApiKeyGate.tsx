
import React, { useState, useEffect } from 'react';

interface ApiKeyGateProps {
  children: React.ReactNode;
}

const ApiKeyGate: React.FC<ApiKeyGateProps> = ({ children }) => {
  const [hasKey, setHasKey] = useState<boolean | null>(null);

  useEffect(() => {
    const checkKey = async () => {
      // @ts-ignore
      const selected = await window.aistudio.hasSelectedApiKey();
      setHasKey(selected);
    };
    checkKey();
  }, []);

  const handleOpenSelectKey = async () => {
    // @ts-ignore
    await window.aistudio.openSelectKey();
    // After selection, we assume success as per guidelines to avoid race condition
    setHasKey(true);
  };

  if (hasKey === true) {
    return <>{children}</>;
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-600 to-purple-700 p-4">
      <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-md w-full text-center">
        <div className="w-20 h-20 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <i className="fa-solid fa-key text-3xl text-indigo-600"></i>
        </div>
        <h1 className="text-2xl font-bold text-slate-800 mb-4">API Key Required</h1>
        <p className="text-slate-600 mb-6 leading-relaxed">
          To use advanced AI features like high-quality image generation (Gemini 3 Pro), you must select a Google AI Studio API key.
        </p>
        <button
          onClick={handleOpenSelectKey}
          className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-3 px-6 rounded-xl transition-all shadow-lg active:scale-95"
        >
          Select API Key
        </button>
        <div className="mt-6 text-sm text-slate-500">
          <a
            href="https://ai.google.dev/gemini-api/docs/billing"
            target="_blank"
            rel="noopener noreferrer"
            className="underline hover:text-indigo-600"
          >
            Learn about API billing and keys
          </a>
        </div>
      </div>
    </div>
  );
};

export default ApiKeyGate;
