
import React, { useState } from 'react';
import { GeminiService } from '../services/geminiService';
import { Question } from '../types';
// @ts-ignore
const { jsPDF } = window.jspdf;

const ExamCenter: React.FC = () => {
  const [questions, setQuestions] = useState<Question[]>([
    { id: '1', text: 'What is 2 + 2?', className: 1 },
    { id: '2', text: 'What color is the sky?', className: 1 },
    { id: '3', text: 'Define photosynthesis in simple terms.', className: 5 },
    { id: '4', text: 'Solve for x: 2x = 10', className: 5 }
  ]);
  const [selectedClass, setSelectedClass] = useState(1);
  const [newQuestion, setNewQuestion] = useState('');
  const [selectedQuestions, setSelectedQuestions] = useState<Set<string>>(new Set());
  const [isGeneratingAi, setIsGeneratingAi] = useState(false);
  const [aiSubject, setAiSubject] = useState('');

  const addQuestion = () => {
    if (!newQuestion.trim()) return;
    const q: Question = {
      id: Date.now().toString(),
      text: newQuestion,
      className: selectedClass
    };
    setQuestions(prev => [...prev, q]);
    setNewQuestion('');
  };

  const generateAiQuestions = async () => {
    if (!aiSubject) return;
    setIsGeneratingAi(true);
    try {
      const suggested = await GeminiService.generateQuestions(selectedClass, aiSubject, 3);
      const newQs = suggested.map(text => ({
        id: Math.random().toString(36).substr(2, 9),
        text,
        className: selectedClass
      }));
      setQuestions(prev => [...prev, ...newQs]);
      setAiSubject('');
    } catch (err) {
      alert("Failed to generate AI questions.");
    } finally {
      setIsGeneratingAi(false);
    }
  };

  const toggleQuestionSelection = (id: string) => {
    const next = new Set(selectedQuestions);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setSelectedQuestions(next);
  };

  const generatePaper = () => {
    if (selectedQuestions.size === 0) return;
    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.getWidth();
    
    doc.setFontSize(24);
    doc.text("Class " + selectedClass + " Examination", pageWidth / 2, 20, { align: 'center' });
    
    doc.setFontSize(12);
    doc.text("Student Name: ________________________", 20, 40);
    doc.text("Date: ________________________", 20, 50);
    
    doc.line(20, 55, pageWidth - 20, 55);
    
    let y = 70;
    doc.setFontSize(14);
    Array.from(selectedQuestions).forEach((id, idx) => {
      const q = questions.find(item => item.id === id);
      if (q) {
        const lines = doc.splitTextToSize(`${idx + 1}. ${q.text}`, pageWidth - 40);
        doc.text(lines, 20, y);
        y += (lines.length * 10) + 20;
      }
    });
    
    doc.save(`Class_${selectedClass}_Exam.pdf`);
  };

  const filteredQuestions = questions.filter(q => q.className === selectedClass);

  return (
    <div className="space-y-8 animate-fade-in">
      <div className="bg-white p-8 rounded-3xl shadow-xl border border-slate-100">
        <h2 className="text-3xl font-black text-slate-800 mb-6 flex items-center gap-3">
          <i className="fa-solid fa-file-invoice text-indigo-600"></i>
          Exam Question Bank
        </h2>
        
        <div className="flex flex-wrap gap-2 mb-8">
          {[1, 2, 3, 4, 5].map(cls => (
            <button
              key={cls}
              onClick={() => {
                setSelectedClass(cls);
                setSelectedQuestions(new Set());
              }}
              className={`px-6 py-2 rounded-full font-bold transition-all ${
                selectedClass === cls ? 'bg-indigo-600 text-white shadow-lg' : 'bg-slate-100 text-slate-600'
              }`}
            >
              Class {cls}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* List and Selector */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-black text-slate-700">Select Questions for Paper</h3>
              <button 
                onClick={generatePaper}
                disabled={selectedQuestions.size === 0}
                className="bg-emerald-500 hover:bg-emerald-600 disabled:bg-slate-200 text-white px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 shadow-lg transition-all"
              >
                <i className="fa-solid fa-print"></i>
                Generate Paper ({selectedQuestions.size})
              </button>
            </div>
            
            <div className="max-h-[400px] overflow-y-auto space-y-2 pr-2">
              {filteredQuestions.map(q => (
                <div 
                  key={q.id}
                  onClick={() => toggleQuestionSelection(q.id)}
                  className={`p-4 rounded-xl border-2 cursor-pointer transition-all flex items-start gap-4 ${
                    selectedQuestions.has(q.id) ? 'border-indigo-500 bg-indigo-50' : 'border-slate-100 hover:border-slate-200'
                  }`}
                >
                  <div className={`w-6 h-6 rounded flex items-center justify-center mt-1 border ${
                    selectedQuestions.has(q.id) ? 'bg-indigo-600 border-indigo-600 text-white' : 'border-slate-300'
                  }`}>
                    {selectedQuestions.has(q.id) && <i className="fa-solid fa-check text-xs"></i>}
                  </div>
                  <p className="text-slate-700 font-medium leading-relaxed">{q.text}</p>
                </div>
              ))}
              {filteredQuestions.length === 0 && (
                <div className="text-center py-12 bg-slate-50 rounded-2xl text-slate-400">
                  No questions in bank for Class {selectedClass}.
                </div>
              )}
            </div>
          </div>

          {/* Add Forms */}
          <div className="space-y-6">
            <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100">
              <h4 className="font-black text-slate-700 mb-4">Add Single Question</h4>
              <textarea
                value={newQuestion}
                onChange={(e) => setNewQuestion(e.target.value)}
                placeholder="Type your question here..."
                className="w-full h-24 p-4 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none mb-4"
              />
              <button
                onClick={addQuestion}
                className="w-full bg-slate-800 hover:bg-slate-900 text-white font-bold py-3 rounded-xl transition-all"
              >
                Save to Bank
              </button>
            </div>

            <div className="bg-indigo-50 p-6 rounded-2xl border border-indigo-100">
              <h4 className="font-black text-indigo-800 mb-4 flex items-center gap-2">
                <i className="fa-solid fa-sparkles"></i>
                AI Question Generator
              </h4>
              <p className="text-xs text-indigo-600 mb-4">Input a subject and AI will suggest 3 questions for this class.</p>
              <input
                type="text"
                value={aiSubject}
                onChange={(e) => setAiSubject(e.target.value)}
                placeholder="e.g. Simple Fractions"
                className="w-full px-4 py-3 rounded-xl border border-indigo-100 focus:ring-2 focus:ring-indigo-500 outline-none mb-4"
              />
              <button
                onClick={generateAiQuestions}
                disabled={isGeneratingAi || !aiSubject}
                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 rounded-xl transition-all flex items-center justify-center gap-2"
              >
                {isGeneratingAi ? <i className="fa-solid fa-spinner fa-spin"></i> : <i className="fa-solid fa-wand-magic-sparkles"></i>}
                Generate Suggestions
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ExamCenter;
